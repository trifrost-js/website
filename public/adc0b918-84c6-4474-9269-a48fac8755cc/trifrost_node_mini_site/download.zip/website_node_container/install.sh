#!/bin/bash

# Install on host (for those good typings in vscode or whichever editor)
npm install

# Install inside container
podman-compose exec website npm install