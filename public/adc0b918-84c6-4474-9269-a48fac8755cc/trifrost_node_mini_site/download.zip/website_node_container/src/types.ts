import {
    type TriFrostRouter,
    type TriFrostContext,
} from '@trifrost/core';

export type Env = {
    PORT: string;
    SIGNOZ_API_TOKEN: string;
};

export type Context<State extends Record<string, unknown> = {}> = TriFrostContext<Env, State>;

export type Router<State extends Record<string, unknown> = {}> = TriFrostRouter<Env, State>;
