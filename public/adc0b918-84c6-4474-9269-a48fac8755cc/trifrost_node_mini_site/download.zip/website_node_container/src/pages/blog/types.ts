export type Post = {
  id: string;
  title: string;
  content: () => JSX.Element;
  comments: {id: string; body: string; on: Date}[];
};
