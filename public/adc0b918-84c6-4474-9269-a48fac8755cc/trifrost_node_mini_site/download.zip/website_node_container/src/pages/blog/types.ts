import {type JSXElement} from "@trifrost/core/modules/JSX";

export type Post = {
    id:string;
    title:string;
    content:() => JSXElement;
    comments:{id:string, body:string, on:Date}[];
};