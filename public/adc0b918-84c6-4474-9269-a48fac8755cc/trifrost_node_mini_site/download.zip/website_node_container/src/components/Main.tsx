import {css} from "../css"

export function Main (props:{children:any}) {
    const cls = css.use('f', 'fv', {
        flexGrow: 1,
        padding: css.$v.space_l,
        [css.media.desktop]: {width: '90rem'},
        [css.media.tablet]: {width: '100%'},
    });

    return (<main className={cls}>{props.children}</main>);
}