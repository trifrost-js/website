import { css } from "../css";

export function Footer() {
	return (
		<footer className={css.use('f', 'fv', 'fa_c', 'fj_c', 'text_body')} style={{marginTop: css.$v.space_xl, fontSize: '1.4rem', letterSpacing: '.05rem'}}>
			<small>©2025 <a href="https://github.com/peterver" target="_blank">Peter Vermeulen</a> &amp; <a href="https://trifrost.dev" target="_blank">TriFrost</a> contributors</small>
			<small>Built with <a href="https://trifrost.dev" target="_blank">TriFrost</a> | Licensed under MIT</small>
		</footer>
	);
}
