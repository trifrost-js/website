export type Env = {
  ASSETS: Fetcher;
  MAIN_DURABLE: DurableObjectNamespace;
  UPTRACE_DSN: string /* DSN from uptrace */;
};
