import autocannon from 'autocannon';

const targets = [
  { name: 'TriFrost', url: 'http://localhost:3001' },
  { name: 'Elysia', url: 'http://localhost:3002' },
  { name: 'Hono', url: 'http://localhost:3003' },
  { name: 'Koa', url: 'http://localhost:3004' },
  { name: 'Express', url: 'http://localhost:3005' },
];

for (const { name, url } of targets) {
  console.log(`\n🔬 Benchmarking ${name} at ${url}`);
  const instance = autocannon({
    url,
    connections: 100,
    pipelining: 10,
    duration: 10,
  });

  autocannon.track(instance, { renderProgressBar: false });

  const result = await new Promise(resolve => {
    instance.on('done', resolve);
  });

  autocannon.printResult(result); // pretty-print to console
}
