import {App} from '@trifrost/core';

const app = new App({})
    .get('/', ctx => ctx.text('Hello world'))
    .boot({ port: 3001 });

